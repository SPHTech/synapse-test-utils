# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['synapse_test_utils']

package_data = \
{'': ['*']}

install_requires = \
['asyncio>=3.4.3,<4.0.0', 'autobahn[serialization]>=22.4.2,<23.0.0']

setup_kwargs = {
    'name': 'synapse-test-utils',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Synapse Test Utils Library\n\n## heartbeat.py\n\nFor Kubernetes(K8s) deployment, readiness and liveness probes are used to check if the container in the pod is ready and still functioning.\n\nUpon start-up, each crossbar component will register a Remote Procedure Call (RPC) on its own "heartbeat" topic. K8s readiness and liveness probes would trigger a [heartbeat component script](heartbeat.py), and this component would call that heartbeat RPC. The crossbar component is deemed to be working if the trigger completes successfully, else the probes would fail and the container in the pod would be restarted.\n\n## probe.py\n\nContains functions to start up a component and block until it is ready, as well as to make a crossbar component that subscribes to a crossbar topic and store the messages it receives.\n',
    'author': 'thewesleyee',
    'author_email': 'wesleyee@sph.com.sg',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
